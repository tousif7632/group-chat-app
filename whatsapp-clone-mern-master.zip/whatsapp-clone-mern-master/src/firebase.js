const firebaseConfig = {
  apiKey: "AIzaSyAPVNEgyDD8BKGZX5TPaxsQu6kGNQgFHbA",
  authDomain: "whatsapp-mern-37eef.firebaseapp.com",
  databaseURL: "https://whatsapp-mern-37eef.firebaseio.com",
  projectId: "whatsapp-mern-37eef",
  storageBucket: "whatsapp-mern-37eef.appspot.com",
  messagingSenderId: "103531269256",
  appId: "1:103531269256:web:f169f6dac9f9f6bdf0a33d",
};
